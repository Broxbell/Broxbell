# Aleatory MD - BOT DE WHATSAPP
<div align="center">
<img src="https://telegra.ph/file/e6018110d95e1a9fc7efe.jpg" alt="Aleatory MD - BOT" width="300" />
</div>
<p align="center">
  <a href="https://github.com/NuevaGeneracionALB/aleatory-md.git"><img title="Autor" src="https://img.shields.io/badge/Autor-Aleatory-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  
Precisa de ajuda? Entre em nosso chat: 

https://chat.whatsapp.com/FT9Szs4fMom7nS2qFNMmye

SÓ SERÁ NECESSÁRIO EXECUTAR OS COMANDOS BÁSICOS DO TERMUX SE APÓS A INSTALAÇÃO DELE, NÃO FOREM DADOS ESSES COMANDOS LISTADOS.

_-_-_-_-_-_-_-_-_

SE PRECISAR, INSTALE A VERSÃO 119 DO TERMUX

https://www.mediafire.com/file/0npdmv51pnttps0/com.termux_0.119.1-119_minAPI21(arm64-v8a,armeabi-v7a,x86,x86_64)(nodpi)_apkmirror.com.apk/file
_-_-_-_-_-_-_-_-_-_

Comandos básicos do Termux necessários para inicialização do bot:

-_1 COMANDO:

termux-change-repo

Confirme, marque a caixinha que contem o nome "by grimler" e prossiga.

-_2 COMANDO:

apt-get upgrade

Será necessário digitar 'y' e confirmar toda vez que for solicitado.

-_3 COMANDO:

apt-get update

Será necessário digitar 'y' e confirmar toda vez que for solicitado.

-_4 COMANDO:

pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y

-_5 COMANDO:

termux-setup-storage

Permita.

__-_-_-_-_-

COMANDO PARA INSTALAR A PASTA DO BOT, APÓS TODAS AS ETAPAS ANTERIORES OU CASO NÃO SEJA NECESSÁRIO AS ETAPAS:

___-_-_-_-_-

cd /sdcard && rm -rf aleatory-md && git clone https://github.com/NuevaGeneracionALB/aleatory-md.git && cd aleatory-md && sh start.sh

_- BASTA COPIAR O COMANDO INTEIRO E COLAR LÁ, NÃO É NECESSÁRIO COPIAR APENAS METADE OU UMA PARTE, É O COMANDO COMPLETO.
